export default  {

   CELSIUS : "CELSIUS",
    
    FAHRENHEIT :"FAHRENHEIT",
    
    KELVIN:"KELVIN",
    
    
    
    }
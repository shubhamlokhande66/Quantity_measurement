
import {Dispatcher} from 'flux';
// import ConstantLength  from "../Constant/ConstantLength";
// import Store from "../Stores/Stores";

// const AppDispatcher = new Dispatcher();


export default new Dispatcher();

// Store.dispatchToken = AppDispatcher.register(payload=>{
//   switch (payload.actionType){
//     case ConstantLength.LENGTH:
//       Store.kilometreToKiloMetre(payload.LENGTHTYPES,payload.LENGTHFROM,payload.LENGTHTO);
//       break;
//       default:
//   }
// });
// Store.dispatchToken = AppDispatcher.register(payload=>{
//   switch (payload.actionType){
//     case ConstantLength.METERS:
//       Store.kilometreToMeter(payload.LENGTHTYPES,payload.LENGTHFROM,payload.LENGTHTO);
//       break;
//       default:
//   }
// });
// Store.dispatchToken = AppDispatcher.register(payload=>{
//   switch (payload.actionType){
//     case ConstantLength.CENTIMETERS:
//       Store.kilometreToCentimetres(payload.LENGTHTYPES,payload.LENGTHFROM,payload.LENGTHTO);
//       break;
//       default:
//   }
// });
// Store.dispatchToken = AppDispatcher.register(payload=>{
//   switch (payload.actionType){
//     case ConstantLength.MILIMETRE:
//       Store.kilometreToMilimetre(payload.LENGTHTYPES,payload.LENGTHFROM,payload.LENGTHTO);
//       break;
//       default:
//   }
// });

// Store.dispatchToken = AppDispatcher.register(payload=>{
//   switch (payload.actionType){
//     case ConstantLength.MICROMETRE:
//       Store.kilometreToMicrometre(payload.LENGTHTYPES,payload.LENGTHFROM,payload.LENGTHTO);
//       break;
//       default:
//   }
// });

// Store.dispatchToken = AppDispatcher.register(payload=>{
//   switch (payload.actionType){
//     case ConstantLength.MILE:
//       Store.kilometreToMile(payload.LENGTHTYPES,payload.LENGTHFROM,payload.LENGTHTO);
//       break;
//       default:
//   }
// });
// Store.dispatchToken = AppDispatcher.register(payload=>{
//   switch (payload.actionType){
//     case ConstantLength.FOOT:
//       Store.kilometreToFoot(payload.LENGTHTYPES,payload.LENGTHFROM,payload.LENGTHTO);
//       break;
//       default:
//   }
// });
// Store.dispatchToken = AppDispatcher.register(payload=>{
//   switch (payload.actionType){
//     case ConstantLength.INCH:
//       Store.kilometreToInch(payload.LENGTHTYPES,payload.LENGTHFROM,payload.LENGTHTO);
//       break;
//       default:
//   }
// });




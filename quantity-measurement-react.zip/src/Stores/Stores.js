import EventEmitter from 'events';
import  Dispatcher from "../Dispatcher/Dispatcher"


class Store extends EventEmitter  {

  constructor(){
    super();
    this.setFromTemperatureText='';


    
  }

    getAll() {
    return this.setFromTemperatureText;
  } 
    

  updateData(obj) {
    this.data = obj;

    console.log(obj);

    this.emit("change");
  }

 
  handleActions = action => {
    console.log(action);

    switch (action.type) {
      case "ADD_TEMP":
        this.updateData({
          ...this.data,
          foo: action.amt,
        //   type:action.TempType
        });
        console.log("Ima FOO");
        break;
      
    
  };
}

//   kilometreToMetres(LENGTHTYPE,LENGTHFROM, LENGTHTO){
//     this.length=LENGTHFROM*1000;
//     this.length
//     this.Change();
// }
 


calculatelength(LENGTHTYPES, LENGTHFROM, LENGTHTO) {
  if (LENGTHTYPES == null || LENGTHFROM == null || LENGTHTO == null) {
      return null;
  }
  let length =[];
  switch (LENGTHTO) {
      case 1:
          this.length = LENGTHTYPES * LENGTHFROM;
          return this.length / 39370;

      case 2:
          this.length = LENGTHTYPES * LENGTHFROM;
          return this.length / 39;
      case 3:
          this.length = LENGTHTYPES * LENGTHFROM;
          return this.length * 2.54;
      case 4:
          this.length = LENGTHTYPES * LENGTHFROM;
          return this.length * 25.4;
      case 5:
          this.length= LENGTHTYPES * LENGTHFROM;
          return this.length * 25400;
      case 6:
         this.length = LENGTHTYPES * LENGTHFROM;
          return this.length / 63360;
      case 7:
          this.length = LENGTHTYPES * LENGTHFROM;
          return this.length / 12;
  


      default:
      return null;
  }
}

Calculatetemp(TEMPRETURETYPES, TEMPRETUREFROM, TEMPRETURETO) {
    if (TEMPRETURETYPES == null || TEMPRETUREFROM == null || TEMPRETURETO == null) {
        return null;
    }
     let temp=0;
    switch (TEMPRETURETO) {
        case 1:
            this.temp = TEMPRETURETYPES;
            return this.temp;
        case 2:
            this.temp = TEMPRETURETYPES * TEMPRETUREFROM;
            return ((this.temp * 9/5) + 32);
        case 3:
            this.temp = TEMPRETURETYPES * TEMPRETUREFROM;
            return (this.temp + 273.15);
        default:
            return null;
        }
    }



  CalculateVolume(VOLUMETYPES, VOLUMEFROM, VOLUMETO) {
    if (VOLUMETYPES == null || VOLUMEFROM == null || VOLUMETO == null) {
        return null;
    }
    
    switch (VOLUMETO) {
        case 1:
            this.Volume = VOLUMETYPES;
            return this.Volume;
        case 2:
            this.Volume = VOLUMETYPES * VOLUMEFROM;
            return this.Volume * 1000
        case 3:
            this.Volume = VOLUMETYPES * VOLUMEFROM;
            return this.Volume / 3.785;
        default:
            return null;
        }
    }

// quantityConversion(LENGTHFROM, LENGTHTO) {
//       console.log("input", LENGTHFROM);
//       console.log("options", LENGTHTO);
//     if (kilometreToKiloMetre= true)
//         return LENGTHFROM;
//     }


//   quantityConversion(LENGTHFROM, LENGTHTO) {
//     console.log("input", LENGTHFROM);
//     console.log("options", LENGTHTO);
//     switch (options) {
//       case "MetresToMetres":
//         return input;

//       case "MetresKilometre":
//         return input / 1000;

//       case "MetresMilimetre":
//         return input / 0.001;

//       case "MetresInch":
//         return input * 39.3701;

//       case "MetresCentimeter":
//         return input * 100;

//       case "MetresFoot":
//         return input * 3.2808;

//       case "MetresMile":
//         return input * 1609;

//       case "MetresMicrometre":
//         return input * 100;




//       case "kilometreToKiloMetre":
//         return input;

//       case "kilometreToMeter":
//         return input * 1000;

//       case "KilometreFoot":
//         return input * 3281;

//       case "KilometreMilimetre":
//         return input / 0.000001;

//       case "KilometreMile":
//         return input / 1.609;

//       case "KilometreInch":
//         return input * 39370.1;

//       case "KilometreCentimetre":
//         return input * 100000;



//       case "CentimetreCentimetre":
//         return input;

//       case "CentimetreInch":
//         return input / 2.54;

//       case "CentimetreFoot":
//         return input / 30.48;

//       case "CentimetreMilimetre":
//         return input / 10;

//       case "CentimetreMile":
//         return input / 160934;

//       case "CentimetreMetres":
//         return input / 100;

//       case "CentimetreKilometre":
//         return input / 100000;

//       case "CentimetreMicrometre":
//         return input / 10000;

//       case "MileMile":
//         return input;

//       case "MileFoot":
//         return input * 5280;

//       case "MileMilimetre":
//         return input * 1609344;

//       case "MileKilometre":
//         return input * 1.60934;

//       case "MileMetres":
//         return input * 1609.34;

//       case "MileInch":
//         return input * 63360;

//       case "MileCentimetre":
//         return input * 160934;

//       case "FootFoot":
//         return input;

//       case "FootMetres":
//         return input / 3.2808;

//       case "FootMilimetre":
//         return input * 304.8;

//       case "FootInch":
//         return input * 12;

//       case "FootMile":
//         return input / 5280;

//       case "FootKilometre":
//         return input / 3280.84;

//       case "FootCentimetre":
//         return input * 30.48;

//       case "InchInch":
//         return input;

//       case "InchCentimetre":
//         return input * 2.54;

//       case "InchFoot":
//         return input / 12;

//       case "InchMilimetre":
//         return input * 25.4;

//       case "InchMile":
//         return input / 63360;

//       case "InchMetres":
//         return input / 39.3701;

//       case "InchKilometre":
//         return input / 39370.1;





//       case "FahrenheitFahrenheit":
//         return input;

//       case "FahrenheitCelsius":
//         return ((input - 32) * 5) / 9;

//       case "FahrenheitKelvin":
//         return ((input - 32) * 5) / 9 + 273.15;

//       case "CelsiusCelcius":
//         return input;

//       case "CelsiusFahrenheit":
//         return (input * 9) / 5 + 32;

//       case "CelsiusKelvin":
//         return input + 273.15;

//       case "KelvinKelvin":
//         return input;

//       case "KelvinFahrenheit":
//         return ((input - 273) * 9) / 5 + 32;

//       case "KelvinCelcius":
//         return input - 273;

//       case "LitersLiters":
//         return input;

//       case "LitersMililitres":
//         return input * 1000;

//       case "LitersGallons":
//         return input / 4.546;

//       case "MililitresMililitres":
//         return input;

//       case "MililitresLiters":
//         return input / 1000;

//       case "MililitresGallons":
//         return input / 4546;

//       case "GallonsGallons":
//         return input;

//       case "GallonsLiters":
//         return input * 4.546;

//       case "GallonsMililitres":
//         return input * 4546;
//     }
//   }
// }


//   Change() {
//     this.emit('change');
//   }

//   addChangeListener(callback) {
//     this.on('change', callback);
//   }

//   removeChangeListener(callback) {
//     this.removeListener('change', callback);
//   }

}
const fluxStore = new Store();
Dispatcher.register(fluxStore.handleActions.bind(fluxStore));
window.fluxStore = fluxStore;
window.Dispatcher = Dispatcher;

export default fluxStore; 
// import React from "react";
// import "./Toolbar.css";


// export default function Toolbar() {
//   return (
    
//       <div className='welcomeNote'>
//          <div className='Welcome'>
//            <h2 style={{color: 'white', width:'500px'}} > Welcome To Quantity Measurement</h2>
//            </div>
//       </div>
    
//   );
// }
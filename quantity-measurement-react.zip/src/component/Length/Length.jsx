import React, { Component } from 'react'
import AppBar from '@material-ui/core/AppBar';
import './Length.css';
import { Card } from '@material-ui/core';
import scale from "../../Images&Logo/scale.svg"
import hot from "../../Images&Logo/hot.svg"
import beaker from "../../Images&Logo/beaker.svg"
import { TextField, MenuItem, Select } from '@material-ui/core';
import LengthConvertor from '../../Stores/Stores';
import LengthAction from "../../Action/Actionlength"

//let objLength=new LengthConvertor();


export default class Length extends Component {
    constructor(props) {
        super(props);
        this.state = {
            setFromLength: '',
            setToLength: '',
            setFromLengthText:'',
            result:"",
            defaultValue1:"0",
            defaultValue2:"0",
            defaultName1:"CM",
            defaultName2:"KM",
            items: LengthConvertor.getAll()
        }
        this.onListChange = this.onListChange.bind(this);
    }




    handleChangeFrom(LENGTHTYPES ,LENGTHFROM, LENGTHTO ) {
        
        LengthAction.kilometreToKiloMetre( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
       
      


        // LengthAction.kilometreToMeter( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.kilometreToCentimetres( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.kilometreToMilimetre( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.kilometreToMicrometre( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.kilometreToMile( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.kilometreToFoot( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.kilometreToInch( LENGTHTYPES ,LENGTHFROM, LENGTHTO);

        // LengthAction.MetresToKiloMetre( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.MetresToMeter( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.MetresToCentimetres( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.MetresToMilimetre( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.MetresToMicrometre( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.MetresToMile( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.MetresToFoot( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.MetresToInch( LENGTHTYPES ,LENGTHFROM, LENGTHTO);

        // LengthAction.CentimetresToKiloMetre( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.CentimetresToMeter( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.CentimetresToCentimetres( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.CentimetresToMilimetre( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.CentimetresToMicrometre( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.CentimetresToMile( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.CentimetresToFoot( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.CentimetresToInch( LENGTHTYPES ,LENGTHFROM, LENGTHTO);

        // LengthAction.MilimetreToKiloMetre( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.MilimetreToMeter( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.MilimetreToCentimetres( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.MilimetreToMilimetre( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.MilimetreToMicrometre( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.MilimetreToMile( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.MilimetreToFoot( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.MilimetreToInch( LENGTHTYPES ,LENGTHFROM, LENGTHTO);

        // LengthAction.MicrometreToKiloMetre( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.MicrometreToMeter( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.MicrometreToCentimetres( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.MicrometreToMilimetre( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.MicrometreToMicrometre( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.MicrometreToMile( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.MicrometreToFoot( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.MicrometreToInch( LENGTHTYPES ,LENGTHFROM, LENGTHTO);

        // LengthAction.MileToKiloMetre( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.MileToMeter( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.MileToCentimetres( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.MileToMilimetre( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.MileToMicrometre( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.MileToMile( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.MileToFoot( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.MileToInch( LENGTHTYPES ,LENGTHFROM, LENGTHTO);

        // LengthAction.FootToKiloMetre( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.FootToMeter( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.FootToCentimetres( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.FootToMilimetre( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.FootToMicrometre( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.FootToMile( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.FootToFoot( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.FootToInch( LENGTHTYPES ,LENGTHFROM, LENGTHTO);

        // LengthAction.InchToKiloMetre( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.InchToMeter( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.InchToCentimetres( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.InchToMilimetre( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.InchToMicrometre( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.InchToMile( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.InchToFoot( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
        // LengthAction.InchToInch( LENGTHTYPES ,LENGTHFROM, LENGTHTO);
    }

    componentDidMount() {
        LengthConvertor.addListener('change', this.onListChange);
      }
    
      componentWillUnmount() {
        LengthConvertor.removeListener('change', this.onListChange);
      }
    
      onListChange() {
        this.setState({
          length: LengthConvertor.getAll()
        });
      }

      
    handleChangeFrom = (event) => {
        this.setState({
            setFromLength: event.target.value
        })
        this.state.setFromLength=event.target.value;
        this.result=LengthConvertor.calculatelength(this.state.setFromLengthText,this.state.setFromLength,this.state.setToLength)
    };
    handleChangeTo = (event) => {
        this.setState({
            setToLength: event.target.value
        })
        this.state.setToLength=event.target.value;
        this.result=LengthConvertor.calculatelength(this.state.setFromLengthText,this.state.setFromLength,this.state.setToLength)
    };
    textChange=(event)=>{
        this.setState({
            setFromLengthText: event.target.value
        })
        this.state.setFromLengthText=event.target.value;
        this.result=LengthConvertor.calculatelength(this.state.setFromLengthText,this.state.setFromLength,this.state.setToLength)
    };

    handleLength = () => {
        this.props.history.push('/length');
    }
    handleTemperature = () => {
        this.props.history.push('/temperature');
    }
    handleVolume = () => {
        this.props.history.push('/volume');
    }
    render() {
        return (
            <div className="homeContainer">
                <AppBar id="appBar">
                    <h2> Welcome To Quantity Measurement</h2>
                </AppBar>
                <div id="chooseType">
                    <h4>CHOOSETYPE</h4>
                </div>
                <div className="cardContainer">

                    <Card id="length"onClick={this.handleLength}>
                        <div>
                            <img src={scale} />
                        </div>
                        <div>
                            Length
                                </div>
                    </Card>
                    <Card id="temperatures"onClick={this.handleTemperature}>
                        <div>
                            <img src={hot} />
                        </div>
                        <div>
                            Temperature
                                </div>
                    </Card>
                    <Card id="volumes"onClick={this.handleVolume}>
                        <div>
                            <img src={beaker} />
                        </div>
                        <div>
                            Volume
                                </div>
                    </Card>
                </div>
                <div id="containerForData">
                    <div>
                        <div id="text">
                            <br /><lable>FROM</lable><br /></div>
                        <div>
                            <TextField className="TextField" type="number" variant="outlined" size="small"  onChange={this.textChange} ></TextField>
                        </div>
                        <div>
                            <Select id="Select" name='defaultValue1' value={this.state.setFromLength} onChange={this.handleChangeFrom}>
                            
                                <MenuItem value={39370}>Kilometer</MenuItem>
                                <MenuItem value={39}>Meter</MenuItem>
                                <MenuItem value={0.393701}>Centimeter</MenuItem>
                                <MenuItem value={0.393701}>Millimeter</MenuItem>
                                <MenuItem value={0.0000393701}>Micrometer</MenuItem>
                                <MenuItem value={63360}>Mile</MenuItem>
                                <MenuItem value={12}>Foot</MenuItem>
                                <MenuItem value={1}>Inch</MenuItem>
                            </Select>
                        </div>
                    </div>
                    <div>
                        <div id="text">
                            <br /><lable>To</lable><br /></div>
                        <div>
                            <TextField className="TextField" type="number" variant="outlined" size="small" value={this.result}  length={this.state.length} ></TextField>  </div>
                        <div>
                            <Select id="Select" value={this.state.setToLength} onChange={this.handleChangeTo} >
                         
                                <MenuItem value={1}>Kilometer</MenuItem>
                                <MenuItem value={2}>Meter</MenuItem>
                                <MenuItem value={3}>Centimeter</MenuItem>
                                <MenuItem value={4}>Millimeter</MenuItem>
                                <MenuItem value={5}>Micrometer</MenuItem>
                                <MenuItem value={6}>Mile</MenuItem>
                                <MenuItem value={7}>Foot</MenuItem>
                                <MenuItem value={8}>Inch</MenuItem>
                            </Select>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}
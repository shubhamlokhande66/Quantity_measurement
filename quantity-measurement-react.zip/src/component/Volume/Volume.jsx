import React, { Component } from 'react'
import AppBar from '@material-ui/core/AppBar';
import './Volume.css';
import { Card } from '@material-ui/core';
import scale from "../../Images&Logo/scale.svg"
import hot from "../../Images&Logo/hot.svg"
import beaker from "../../Images&Logo/beaker.svg"
import { TextField, MenuItem, Select } from '@material-ui/core';
import VolumeConvertor from '../../Stores/Stores';
import VolumeAction from "../../Action/ActionVolume"




export default class Volume extends Component {
    constructor(props) {
        super(props);
        this.state = {
            setFromVolume: '',
            setToVolume: '',
            setFromVolumeText:'',
            defaultValue1:"0",
            result:""
        }
    }



    handleVolume(VOLUMETYPES ,VOLUMEFROM, VOLUMETO) {
        VolumeAction.LitresToLitres( VOLUMETYPES ,VOLUMEFROM, VOLUMETO);
        VolumeAction.LitresToMililiters( VOLUMETYPES ,VOLUMEFROM, VOLUMETO);
        VolumeAction.LitresToGallons( VOLUMETYPES ,VOLUMEFROM, VOLUMETO);
  
        VolumeAction.MililitersToLitres( VOLUMETYPES ,VOLUMEFROM, VOLUMETO);
        VolumeAction.MililitersToMililiters( VOLUMETYPES ,VOLUMEFROM, VOLUMETO);
        VolumeAction.MililitersToGallons( VOLUMETYPES ,VOLUMEFROM, VOLUMETO);
  
        VolumeAction.GallonsToLitres( VOLUMETYPES ,VOLUMEFROM, VOLUMETO);
        VolumeAction.GallonsToMililiters( VOLUMETYPES ,VOLUMEFROM, VOLUMETO);
        VolumeAction.GallonsToGallons( VOLUMETYPES ,VOLUMEFROM, VOLUMETO);
       }
    
    handleChangesFrom = (event) => {
        this.setState({
            setFromVolume: event.target.value
        })
        this.state.setFromVolume=event.target.value;
        this.result=VolumeConvertor.CalculateVolume(this.state.setFromVolumeText,this.state.setFromVolume,this.state.setToVolume)
    };
    handleChangesToo = (event) => {
        this.setState({
            setToVolume: event.target.value
        })
        this.state.setToVolume=event.target.value;
        this.result=VolumeConvertor.CalculateVolume(this.state.setFromVolumeText,this.state.setFromVolume,this.state.setToVolume)
    };
    textsChanges=(event)=>{
        this.setState({
            setFromVolumeText: event.target.value
        })
        this.state.setFromVolumeText=event.target.value;
        this.result=VolumeConvertor.CalculateVolume(this.state.setFromVolumeText,this.state.setFromVolume,this.state.setToVolume)
    };
    handleLength = () => {
        this.props.history.push('/length');
    }
    handleTemperature = () => {
        this.props.history.push('/temperature');
    }
    handleVolume = () => {
        this.props.history.push('/volume');
    }
    render() {
        return (
            <div className="homeContainer">
                <AppBar id="appBar">
                    <h2> Welcome To Quantity Measurement</h2>
                </AppBar>
                <div id="chooseType">
                    <h4>CHOOSETYPE</h4>
                </div>
                <div className="cardContainer">

                    <Card id="lengths"onClick={this.handleLength}>
                        <div>
                            <img src={scale} />
                        </div>
                        <div>
                            Length
                            </div>
                    </Card>
                    <Card id="temperatures"onClick={this.handleTemperature}>
                        <div>
                            <img src={hot} />
                        </div>
                        <div>
                            Temperature
                            </div>
                    </Card>
                    <Card id="volume"onClick={this.handleVolume}>
                        <div>
                            <img src={beaker} />
                        </div>
                        <div>
                            Volume
                            </div>
                    </Card>
                </div>
                <div id="containerForData">
                    <div>
                        <div id="text">
                            <br /><lable>FROM</lable><br /></div>
                        <div>
                            <TextField className="TextField" type="number" variant="outlined" size="small" onChange={this.textsChanges} value={this.state.defaultValue1} ></TextField>
                        </div>
                        <div>
                            <Select id="Select" value={this.state.setFromVolume} onChange={this.handleChangesFrom}>
                                
                                <MenuItem value={1}>Litres</MenuItem>
                                <MenuItem value={1000}>Millilitres</MenuItem>
                                <MenuItem value={0.000264172}>Gallons</MenuItem>
                            </Select>
                        </div>
                    </div>
                    <div>
                        <div id="text">
                            <br /><lable>To</lable><br /></div>
                        <div>
                            <TextField className="TextField" type="number" variant="outlined" size="small" value={this.result} value={this.state.defaultValue1}></TextField>  </div>
                        <div>
                            <Select id="Select" value={this.state.setToVolume} onChange={this.handleChangesToo}>
                              
                                <MenuItem value={1}>Litres</MenuItem>
                                <MenuItem value={2}>Millilitres</MenuItem>
                                <MenuItem value={3}>Gallons</MenuItem>
                            </Select>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}